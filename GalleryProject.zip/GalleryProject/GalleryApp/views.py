from django.shortcuts import render,redirect

from django.views import View

from . forms import RegisterForm , LoginForm,ImageForm

from django.contrib.auth import authenticate,login,logout

from . models import CategoryModel,ImageModel

from django.contrib import messages


# Create your views here.

def signout_view(request):

    logout(request)
    messages.success(request,' User Logged Out')

    return redirect('home')


class home_view(View):

    


    def get(self,request):
        if request.user.is_authenticated:
            return redirect('gallery')
        forms=LoginForm()

        context={'forms':forms}


        return render(request,'home.html',context)


    def post(self,request):
        
        username=request.POST.get('username')
        password=request.POST.get('password')

        user=authenticate(username=username,password=password)
        print(user)
        if user is not None:

            login(request,user)
            messages.success(request,' User Logged In')

            return redirect('gallery')


        return redirect('home')


class register_view(View):

    def get(self,request):

        def get(self,request):
            if request.user.is_authenticated:
                return redirect('gallery')


        forms=RegisterForm()

        context={'forms':forms}



        return render(request,'register.html',context)


    def post(self,request):


        forms=RegisterForm(request.POST)
        if forms.is_valid():
            forms.save()
            messages.success(request,'Successfully User Registered')

            return redirect('home')

        context={'forms':forms}

        return render(request,'register.html',context)


class gallery_view(View):

    def get(self,request):


        category=CategoryModel.objects.all()

        images=ImageModel.objects.all()

        context={'cat':category,'images':images}

        return render(request,'gallery.html',context)


    def post(self,request):

        return render(request,'gallery.html')


class Cat_view(View):

    def get(self,request,id):

        images=ImageModel.objects.filter(cat=id)

       

        category=CategoryModel.objects.all()
  

        context={'images':images,'cat':category}

        return render(request,'gallery.html',context)


class addimage_view(View):

    def get(self,request):


        forms=ImageForm()
        context={'forms':forms}

        return render(request,'addimage.html',context)

    def post(self,request):

        forms=ImageForm(request.POST,request.FILES)
        if forms.is_valid():

            task=forms.save(commit=False)
            task.uploaded_by=request.user
            task.save()
            messages.success(request,'Successfully User Registered')
            
            return redirect('gallery')

        return render(request,'addimage.html')

class myupload_view(View):

    def get(self,request):

        images=ImageModel.objects.filter(uploaded_by=request.user)

        context={'images':images}

        return render(request,'myupload.html',context)